display_width = 800
display_height = 600

black = (0,0,0)
gray = (169,169,169)
dark_gray = (100,100,100)
white = (255,255,255)
red = (150,0,0)
green = (0,150,0)
bright_red = (255,0,0)
bright_green = (0,255,0)
blue = (0,0,150)
bright_blue = (0,0,255)
yellow = (255,255,102)
bright_yellow = (255,255,0)

block_color = (53,115,255)

qblocosx = 10
qblocosy = 3

botao_jogar = (40, 450, 140, 50)
botao_sair = (610, 450, 140, 50)
botao_recordes = (230, 450, 140, 50)
botao_controles = (420, 450, 140, 50)
botao_voltar = (40, 50, 140, 50)

botao_mouse = (340, 100, 140, 50)
botao_teclado = (340, 200, 140, 50)
botao_ds4 = (340, 300, 140, 50)
botao_camera = (340, 400, 140, 50)

botao_mouse2 = (60, 170, 140, 50)
botao_teclado2 = (260, 170, 140, 50)
botao_ds42 = (450, 170, 140, 50)
botao_camera2 = (640, 170, 140, 50)

vel_inicial_bola = [0, 8]
pos_inicial_bola = [420, 320]

velx_max_bola = 2

raio_bola = 6